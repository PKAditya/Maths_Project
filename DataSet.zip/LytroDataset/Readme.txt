====================================================================================
Lytro Multi-focus Dataset:

This dataset contains 20 pairs of color multi-focus images of size 520�520 pixels 
and four series of multi-focus images with three sources.

Please cite the following paper if you use this dataset:

M. Nejati, S. Samavi, S. Shirani, "Multi-focus Image Fusion Using Dictionary-Based Sparse Representation", Information Fusion, vol. 25, Sept. 2015, pp. 72-84. 

doi:10.1016/j.inffus.2014.10.004
====================================================================================
